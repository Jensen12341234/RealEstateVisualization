import json
import math
from datetime import datetime
import scrapy
from RealEstate.items import House730RentItem

from RealEstate.spiders.House730GeneralSpider import House730GeneralSpider


class House730RentSpider(House730GeneralSpider):
    name = "house730rentspider"

    def __init__(self):
        super().__init__(
            start_url="https://api.house730.com/Property/SearchProperty?language=zh-hk&cityen=hk&platform=wap"
            , page_count=100)

    def send_requests(self, page, callback):
        body = {"pageCount": self.page_count, "pageIndex": page, "rentalType": "rent", "regionCon": [], "searchCon": []}

        headers = {"Accept": "application/json, text/plain, */*",
                   "Accept-Language": "zh-TW,zh;q=0.9,en-US;q=0.8,en;q=0.7", "Connection": "keep-alive",
                   "Content-Type": "application/json;charset=UTF-8", "Origin": "https://m.house730.com",
                   "Referer": "https://m.house730.com/", "Sec-Fetch-Dest": "empty", "Sec-Fetch-Mode": "cors",
                   "Sec-Fetch-Site": "same-site",
                   "User-Agent": "Mozilla/5.0 (Linux; Android 6.0; Nexus 5 Build/MRA58N) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/102.0.0.0 Mobile Safari/537.36",
                   "sec-ch-ua": '" Not A;Brand";v="99", "Chromium";v="102", "Google Chrome";v="102"', }
        yield scrapy.Request(method="POST", url=self.start_url, headers=headers, body=json.dumps(body),
                             callback=callback)

    def page_item(self, data):
        house730rentitem = House730RentItem()
        house730rentitem["propertyID"] = data["propertyID"]
        house730rentitem["regionCode"] = data["regionCode"]
        house730rentitem["regionName"] = data["regionName"]
        house730rentitem["regionNameWithCulture"] = data["regionNameWithCulture"]
        house730rentitem["zoneCode"] = data["zoneCode"]
        house730rentitem["zoneName"] = data["zoneName"]
        house730rentitem["zoneNameEN"] = data["zoneNameEN"]
        house730rentitem["zoneNameZH"] = data["zoneNameZH"]
        house730rentitem["zoneNameWithCulture"] = data["zoneNameWithCulture"]
        house730rentitem["gscopeCode"] = data["gscopeCode"]
        house730rentitem["gscopeName"] = data["gscopeName"]
        house730rentitem["gscopeNameEN"] = data["gscopeNameEN"]
        house730rentitem["gscopeNameZH"] = data["gscopeNameZH"]
        house730rentitem["gscopeNameWithCulture"] = data["gscopeNameWithCulture"]
        house730rentitem["estateID"] = data["estateID"]
        house730rentitem["parentEstateID"] = data["parentEstateID"]
        house730rentitem["buildingID"] = data["buildingID"]
        house730rentitem["unitID"] = data["unitID"]
        house730rentitem["estateName"] = data["estateName"]
        house730rentitem["estateNameZH"] = data["estateNameZH"]
        house730rentitem["estateNameEN"] = data["estateNameEN"]
        house730rentitem["estateNameWithCulture"] = data["estateNameWithCulture"]
        house730rentitem["phaseWithCulture"] = data["phaseWithCulture"]
        house730rentitem["phase"] = data["phase"]
        house730rentitem["phaseEn"] = data["phaseEn"]
        house730rentitem["phaseZH"] = data["phaseZH"]
        house730rentitem["estateAddressWithCulture"] = data["estateAddressWithCulture"]
        house730rentitem["buildingName"] = data["buildingName"]
        house730rentitem["buildingAge"] = data["buildingAge"]
        house730rentitem["propertySource"] = data["propertySource"]
        house730rentitem["propertySourceWithCulture"] = data["propertySourceWithCulture"]
        house730rentitem["rentalType"] = data["rentalType"]
        house730rentitem["rentalTypeWithCulture"] = data["rentalTypeWithCulture"]
        house730rentitem["isLinkParking"] = data["isLinkParking"]
        house730rentitem["buildingArea"] = data["buildingArea"]
        house730rentitem["saleableArea"] = data["saleableArea"]
        house730rentitem["isVerifyArea"] = data["isVerifyArea"]
        house730rentitem["declarIsNeeded"] = data["declarIsNeeded"]
        house730rentitem["propertyCategory"] = data["propertyCategory"]
        house730rentitem["propertyCategoryWithCulture"] = data["propertyCategoryWithCulture"]
        house730rentitem["salePrice"] = data["salePrice"]
        house730rentitem["rentPrice"] = data["rentPrice"]
        house730rentitem["buildingAvgPrice"] = data["buildingAvgPrice"]
        house730rentitem["saleableAvgPrice"] = data["saleableAvgPrice"]
        house730rentitem["dealAvgDate"] = data["dealAvgDate"]
        house730rentitem["dealAvgDateMonth"] = data["dealAvgDateMonth"]
        house730rentitem["dealAvgPrice"] = data["dealAvgPrice"]
        house730rentitem["beginRentTime"] = data["beginRentTime"]
        house730rentitem["propertyNo"] = data["propertyNo"]
        house730rentitem["titleWithCulture"] = data["titleWithCulture"]
        house730rentitem["isTitleCurrentCulture"] = data["isTitleCurrentCulture"]
        house730rentitem["isJoinAgentIntroduce"] = data["isJoinAgentIntroduce"]
        house730rentitem["unitFloor"] = data["unitFloor"]
        house730rentitem["unitFloorWithCulture"] = data["unitFloorWithCulture"]
        house730rentitem["roomNumber"] = data["roomNumber"]
        house730rentitem["toiletNumber"] = data["toiletNumber"]
        house730rentitem["toiletNumberWithCulture"] = data["toiletNumberWithCulture"]
        house730rentitem["roomNumberWithCulture"] = data["roomNumberWithCulture"]
        house730rentitem["propertyManagementFee"] = data["propertyManagementFee"]
        house730rentitem["imagePath"] = data["imagePath"]
        house730rentitem["topType"] = data["topType"]
        house730rentitem["topTypeWithCulture"] = data["topTypeWithCulture"]
        house730rentitem["approvalStatus"] = data["approvalStatus"]
        house730rentitem["approvalStatusWithCulture"] = data["approvalStatusWithCulture"]
        house730rentitem["approvalTime"] = data["approvalTime"]
        house730rentitem["propertyStatus"] = data["propertyStatus"]
        house730rentitem["propertyStatusWithCulture"] = data["propertyStatusWithCulture"]
        house730rentitem["paymentStatus"] = data["paymentStatus"]
        house730rentitem["paymentStatusWithCulture"] = data["paymentStatusWithCulture"]
        house730rentitem["publicTime"] = data["publicTime"]
        house730rentitem["expireTime"] = data["expireTime"]
        house730rentitem["browseNumber"] = data["browseNumber"]
        house730rentitem["imageNumber"] = data["imageNumber"]
        house730rentitem["collectionNumber"] = data["collectionNumber"]
        house730rentitem["leaveMessageNumber"] = data["leaveMessageNumber"]
        house730rentitem["isNamely"] = data["isNamely"]
        house730rentitem["isVerify"] = data["isVerify"]
        house730rentitem["isVerifyImage"] = data["isVerifyImage"]
        house730rentitem["isVerifyLabel"] = data["isVerifyLabel"]
        house730rentitem["refreshTime"] = data["refreshTime"]
        house730rentitem["recommendNumber"] = data["recommendNumber"]
        house730rentitem["saleForm"] = data["saleForm"]
        house730rentitem["saleFormWithCulture"] = data["saleFormWithCulture"]
        house730rentitem["userID"] = data["userID"]
        house730rentitem["accountID"] = data["accountID"]
        house730rentitem["updateTime"] = data["updateTime"]
        house730rentitem["isAdminOffLine"] = data["isAdminOffLine"]
        house730rentitem["introduceWithCulture"] = data["introduceWithCulture"]
        house730rentitem["isIntroduceCurrentCulture"] = data["isIntroduceCurrentCulture"]
        house730rentitem["longitudes"] = data["longitudes"]
        house730rentitem["latitudes"] = data["latitudes"]
        house730rentitem["subCategory"] = data["subCategory"]
        house730rentitem["subCategoryInfos"] = data["subCategoryInfos"]
        house730rentitem["similar"] = data["similar"]
        house730rentitem["images"] = data["images"]
        house730rentitem["planImages"] = data["planImages"]
        house730rentitem["rentLabel"] = data["rentLabel"]
        house730rentitem["rentLabelInfos"] = data["rentLabelInfos"]
        house730rentitem["propertyLabel"] = data["propertyLabel"]
        house730rentitem["propertyLabelInfos"] = data["propertyLabelInfos"]
        house730rentitem["propertyTag"] = data["propertyTag"]
        house730rentitem["departmentID"] = data["departmentID"]
        house730rentitem["companyID"] = data["companyID"]
        house730rentitem["companyNameWithCulture"] = data["companyNameWithCulture"]
        house730rentitem["vr"] = data["vr"]
        house730rentitem["vrs"] = data["vrs"]
        house730rentitem["videos"] = data["videos"]
        house730rentitem["isHideAgent"] = data["isHideAgent"]
        house730rentitem["isHide"] = data["isHide"]
        house730rentitem["isDelete"] = data["isDelete"]
        house730rentitem["companySource"] = data["companySource"]
        house730rentitem["hideType"] = data["hideType"]
        yield house730rentitem

import json
import math
from datetime import datetime
import scrapy
from RealEstate.items import House730Item
from RealEstate.spiders.House730GeneralSpider import House730GeneralSpider


class House730NewEstateSpider(House730GeneralSpider):
    name = "house730newestatespider"

    def __init__(self):
        super().__init__(start_url="https://api.house730.com/NewEstate/SearchNewEstate?language=zh-hk&cityen=hk"
                                   "&platform=wap "
                         , page_count=100)

    def send_requests(self, page, callback):
        body = {"pageCount": self.page_count, "pageIndex": page, "target": "Price", "areaIdOne": [1], "areaIds": [1],
                "areaIdOneText": "香港", "areaIdTwoText": "", "estateStatusesText": [], "saleStatusesText": "",
                "newFeatureText": "", "multimediaText": ""}

        headers = {"Accept": "application/json, text/plain, */*",
                   "Accept-Language": "zh-TW,zh;q=0.9,en-US;q=0.8,en;q=0.7", "Connection": "keep-alive",
                   "Content-Type": "application/json;charset=UTF-8", "Origin": "https://m.house730.com",
                   "Referer": "https://m.house730.com/", "Sec-Fetch-Dest": "empty", "Sec-Fetch-Mode": "cors",
                   "Sec-Fetch-Site": "same-site",
                   "User-Agent": "Mozilla/5.0 (Linux; Android 6.0; Nexus 5 Build/MRA58N) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/102.0.0.0 Mobile Safari/537.36",
                   "sec-ch-ua": '" Not A;Brand";v="99", "Chromium";v="102", "Google Chrome";v="102"', }
        yield scrapy.Request(method="POST", url=self.start_url, headers=headers, body=json.dumps(body),
                             callback=callback)

    # def start_requests(self):
    #     yield from self.send_requests(page=1, callback=self.parse_first_page)
    #
    # def parse_first_page(self, response):
    #     if response.status == 200:
    #         response_result = response.json()["result"]
    #         total_items = response_result["count"]
    #         data_list = response_result["data"]
    #
    #         for data in data_list:
    #             yield from self.page_item(data)
    #
    #         total_page = math.ceil(total_items / self.page_count)
    #         for page in range(2, total_page):
    #             yield from self.send_requests(page=page, callback=self.parse_page)
    #
    # def parse_page(self, response):
    #     if response.status == 200:
    #         response_result = response.json()["result"]
    #         data_list = response_result["data"]
    #         for data in data_list:
    #             yield from self.page_item(data)

    def page_item(self, data):
        house730_item = House730Item()
        house730_item["avgPrice"] = data["avgPrice"]
        house730_item["minUnitPrice"] = data["minUnitPrice"]
        house730_item["maxUnitPrice"] = data["maxUnitPrice"]
        house730_item["minTotalPrice"] = data["minTotalPrice"]
        house730_item["maxTotalPrice"] = data["maxTotalPrice"]
        house730_item["estateId"] = data["estateId"]
        house730_item["areaId"] = data["areaId"]
        house730_item["estateName"] = data["estateName"]
        house730_item["estateNameEn"] = data["estateNameEn"]
        house730_item["estateNameZH"] = data["estateNameZH"]
        house730_item["estateNameWithCulture"] = data["estateNameWithCulture"]
        house730_item["detailAddressWithCulture"] = data["detailAddressWithCulture"]
        house730_item["newEstateLabel"] = data["newEstateLabel"]
        house730_item["newEstateLabelWithCulture"] = data["newEstateLabelWithCulture"]
        house730_item["minSalePrice"] = data["minSalePrice"]
        house730_item["maxSalePrice"] = data["maxSalePrice"]
        house730_item["minSaleableArea"] = data["minSaleableArea"]
        house730_item["maxSaleableArea"] = data["maxSaleableArea"]
        house730_item["priceListType"] = data["priceListType"]
        house730_item["priceListTypeWithCulture"] = data["priceListTypeWithCulture"]
        house730_item["defaultImage"] = data["defaultImage"]
        house730_item["estateStatus"] = data["estateStatus"]
        house730_item["estateStatusWithCulture"] = data["estateStatusWithCulture"]
        house730_item["saleStatus"] = data["saleStatus"]
        house730_item["saleStatusWithCulture"] = data["saleStatusWithCulture"]
        house730_item["hasAgent"] = data["hasAgent"]
        house730_item["featureDictionary"] = data["featureDictionary"]
        house730_item["isVideo"] = data["isVideo"]
        house730_item["isVr"] = data["isVr"]
        house730_item["isFly"] = data["isFly"]
        house730_item["flys"] = data["flys"]
        house730_item["isShowVRChat"] = data["isShowVRChat"]
        house730_item["isDeveloperAd"] = data["isDeveloperAd"]
        house730_item["priceListNumber"] = data["priceListNumber"]
        house730_item["areas"] = data["areas"]
        house730_item["areaCode"] = data["areaCode"]
        house730_item["areaNameWithCulture"] = data["areaNameWithCulture"]
        house730_item["regionCode"] = data["regionCode"]
        house730_item["regionNameWithCulture"] = data["regionNameWithCulture"]
        house730_item["zoneCode"] = data["zoneCode"]
        house730_item["zoneNameWithCulture"] = data["zoneNameWithCulture"]
        house730_item["gscopeCode"] = data["gscopeCode"]
        house730_item["gscopeNameWithCulture"] = data["gscopeNameWithCulture"]
        house730_item["developerWithCulture"] = data["developerWithCulture"]
        house730_item["minBuildingArea"] = data["minBuildingArea"]
        house730_item["maxBuildingArea"] = data["maxBuildingArea"]
        yield house730_item

import json
import math
from datetime import datetime
import scrapy
from RealEstate.items import House730DealSaleItem
from RealEstate.spiders.House730GeneralSpider import House730GeneralSpider


class House730DealSaleSpider(House730GeneralSpider):
    name = "house730dealsalespider"

    def __init__(self):
        super().__init__(start_url="https://api.house730.com/Deal/SearchDeal?language=zh-hk&cityen=hk&platform=wap", page_count=100)

    def send_requests(self, page, callback):
        body = {"pageIndex": 1, "pageCount": self.page_count, "dealType": "S"}

        headers = {"Accept": "application/json, text/plain, */*",
                   "Accept-Language": "zh-TW,zh;q=0.9,en-US;q=0.8,en;q=0.7", "Connection": "keep-alive",
                   "Content-Type": "application/json;charset=UTF-8", "Origin": "https://m.house730.com",
                   "Referer": "https://m.house730.com/", "Sec-Fetch-Dest": "empty", "Sec-Fetch-Mode": "cors",
                   "Sec-Fetch-Site": "same-site",
                   "User-Agent": "Mozilla/5.0 (Linux; Android 6.0; Nexus 5 Build/MRA58N) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/102.0.0.0 Mobile Safari/537.36",
                   "sec-ch-ua": '" Not A;Brand";v="99", "Chromium";v="102", "Google Chrome";v="102"', }
        yield scrapy.Request(method="POST", url=self.start_url, headers=headers, body=json.dumps(body),
                             callback=callback)

    def page_item(self, data):
        house730DealSaleItem = House730DealSaleItem()
        house730DealSaleItem["dealCode"] = data["dealCode"]
        house730DealSaleItem["dealID"] = data["dealID"]
        house730DealSaleItem["dealTime"] = data["dealTime"]
        house730DealSaleItem["titleWithCulture"] = data["titleWithCulture"]
        house730DealSaleItem["regionCode"] = data["regionCode"]
        house730DealSaleItem["regionNameWithCulture"] = data["regionNameWithCulture"]
        house730DealSaleItem["zoneCode"] = data["zoneCode"]
        house730DealSaleItem["zoneNameWithCulture"] = data["zoneNameWithCulture"]
        house730DealSaleItem["gscopeCode"] = data["gscopeCode"]
        house730DealSaleItem["gscopeNameWithCulture"] = data["gscopeNameWithCulture"]
        house730DealSaleItem["estateID"] = data["estateID"]
        house730DealSaleItem["parentEstateID"] = data["parentEstateID"]
        house730DealSaleItem["estateNameWithCulture"] = data["estateNameWithCulture"]
        house730DealSaleItem["phaseNameWithCulture"] = data["phaseNameWithCulture"]
        house730DealSaleItem["buildingID"] = data["buildingID"]
        house730DealSaleItem["dealPrice"] = data["dealPrice"]
        house730DealSaleItem["buildingArea"] = data["buildingArea"]
        house730DealSaleItem["saleableArea"] = data["saleableArea"]
        house730DealSaleItem["buildingAvgPrice"] = data["buildingAvgPrice"]
        house730DealSaleItem["saleableAvgPrice"] = data["saleableAvgPrice"]
        house730DealSaleItem["addressWithCulture"] = data["addressWithCulture"]
        house730DealSaleItem["contractMode"] = data["contractMode"]
        house730DealSaleItem["roomNoWithCulture"] = data["roomNoWithCulture"]
        house730DealSaleItem["floorWithCulture"] = data["floorWithCulture"]
        house730DealSaleItem["totalFloor"] = data["totalFloor"]
        house730DealSaleItem["buildingNameWithCulture"] = data["buildingNameWithCulture"]
        house730DealSaleItem["direction"] = data["direction"]
        house730DealSaleItem["registerTime"] = data["registerTime"]
        house730DealSaleItem["marketLevel"] = data["marketLevel"]
        house730DealSaleItem["unitNo"] = data["unitNo"]
        house730DealSaleItem["registerAddress1WithCulture"] = data["registerAddress1WithCulture"]
        house730DealSaleItem["registerAddress2WithCulture"] = data["registerAddress2WithCulture"]
        house730DealSaleItem["buildingUsage"] = data["buildingUsage"]
        house730DealSaleItem["buildingUsageDescWithCulture"] = data["buildingUsageDescWithCulture"]
        house730DealSaleItem["unitUsage"] = data["unitUsage"]
        house730DealSaleItem["unitUsageDescWithCulture"] = data["unitUsageDescWithCulture"]
        house730DealSaleItem["dealBuildingAge"] = data["dealBuildingAge"]
        house730DealSaleItem["evaluateNo"] = data["evaluateNo"]
        house730DealSaleItem["propertyReferNo"] = data["propertyReferNo"]
        house730DealSaleItem["lastRegisterNo"] = data["lastRegisterNo"]
        house730DealSaleItem["lastDealPrice"] = data["lastDealPrice"]
        house730DealSaleItem["lastDealTime"] = data["lastDealTime"]
        house730DealSaleItem["lastRegisterTime"] = data["lastRegisterTime"]
        house730DealSaleItem["lastBuildingAvgPrice"] = data["lastBuildingAvgPrice"]
        house730DealSaleItem["lastHoldDays"] = data["lastHoldDays"]
        house730DealSaleItem["profit"] = data["profit"]
        house730DealSaleItem["profitPercent"] = data["profitPercent"]
        house730DealSaleItem["profitPercentYear"] = data["profitPercentYear"]
        house730DealSaleItem["dealType"] = data["dealType"]
        house730DealSaleItem["historyDeal"] = data["historyDeal"]
        house730DealSaleItem["dealSource"] = data["dealSource"]
        yield house730DealSaleItem

import json
import scrapy
from RealEstate.items import House730DealRentItem
from RealEstate.spiders.House730GeneralSpider import House730GeneralSpider


class House730DealSaleSpider(House730GeneralSpider):
    name = "house730dealrentspider"

    def __init__(self):
        super().__init__(start_url="https://api.house730.com/Deal/SearchDeal?language=zh-hk&cityen=hk&platform=wap", page_count=100)

    def send_requests(self, page, callback):
        body = {"pageIndex": 1, "pageCount": self.page_count, "dealType": "R"}

        headers = {"Accept": "application/json, text/plain, */*",
                   "Accept-Language": "zh-TW,zh;q=0.9,en-US;q=0.8,en;q=0.7", "Connection": "keep-alive",
                   "Content-Type": "application/json;charset=UTF-8", "Origin": "https://m.house730.com",
                   "Referer": "https://m.house730.com/", "Sec-Fetch-Dest": "empty", "Sec-Fetch-Mode": "cors",
                   "Sec-Fetch-Site": "same-site",
                   "User-Agent": "Mozilla/5.0 (Linux; Android 6.0; Nexus 5 Build/MRA58N) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/102.0.0.0 Mobile Safari/537.36",
                   "sec-ch-ua": '" Not A;Brand";v="99", "Chromium";v="102", "Google Chrome";v="102"', }
        yield scrapy.Request(method="POST", url=self.start_url, headers=headers, body=json.dumps(body),
                             callback=callback)

    def page_item(self, data):
        house730DealRentItem = House730DealRentItem()
        house730DealRentItem["dealCode"] = data["dealCode"]
        house730DealRentItem["dealID"] = data["dealID"]
        house730DealRentItem["dealTime"] = data["dealTime"]
        house730DealRentItem["titleWithCulture"] = data["titleWithCulture"]
        house730DealRentItem["regionCode"] = data["regionCode"]
        house730DealRentItem["regionNameWithCulture"] = data["regionNameWithCulture"]
        house730DealRentItem["zoneCode"] = data["zoneCode"]
        house730DealRentItem["zoneNameWithCulture"] = data["zoneNameWithCulture"]
        house730DealRentItem["gscopeCode"] = data["gscopeCode"]
        house730DealRentItem["gscopeNameWithCulture"] = data["gscopeNameWithCulture"]
        house730DealRentItem["estateID"] = data["estateID"]
        house730DealRentItem["parentEstateID"] = data["parentEstateID"]
        house730DealRentItem["estateNameWithCulture"] = data["estateNameWithCulture"]
        house730DealRentItem["phaseNameWithCulture"] = data["phaseNameWithCulture"]
        house730DealRentItem["buildingID"] = data["buildingID"]
        house730DealRentItem["dealPrice"] = data["dealPrice"]
        house730DealRentItem["buildingArea"] = data["buildingArea"]
        house730DealRentItem["saleableArea"] = data["saleableArea"]
        house730DealRentItem["buildingAvgPrice"] = data["buildingAvgPrice"]
        house730DealRentItem["saleableAvgPrice"] = data["saleableAvgPrice"]
        house730DealRentItem["addressWithCulture"] = data["addressWithCulture"]
        house730DealRentItem["contractMode"] = data["contractMode"]
        house730DealRentItem["roomNoWithCulture"] = data["roomNoWithCulture"]
        house730DealRentItem["floorWithCulture"] = data["floorWithCulture"]
        house730DealRentItem["totalFloor"] = data["totalFloor"]
        house730DealRentItem["buildingNameWithCulture"] = data["buildingNameWithCulture"]
        house730DealRentItem["direction"] = data["direction"]
        house730DealRentItem["registerTime"] = data["registerTime"]
        house730DealRentItem["marketLevel"] = data["marketLevel"]
        house730DealRentItem["unitNo"] = data["unitNo"]
        house730DealRentItem["registerAddress1WithCulture"] = data["registerAddress1WithCulture"]
        house730DealRentItem["registerAddress2WithCulture"] = data["registerAddress2WithCulture"]
        house730DealRentItem["buildingUsage"] = data["buildingUsage"]
        house730DealRentItem["buildingUsageDescWithCulture"] = data["buildingUsageDescWithCulture"]
        house730DealRentItem["unitUsage"] = data["unitUsage"]
        house730DealRentItem["unitUsageDescWithCulture"] = data["unitUsageDescWithCulture"]
        house730DealRentItem["dealBuildingAge"] = data["dealBuildingAge"]
        house730DealRentItem["evaluateNo"] = data["evaluateNo"]
        house730DealRentItem["propertyReferNo"] = data["propertyReferNo"]
        house730DealRentItem["lastRegisterNo"] = data["lastRegisterNo"]
        house730DealRentItem["lastDealPrice"] = data["lastDealPrice"]
        house730DealRentItem["lastDealTime"] = data["lastDealTime"]
        house730DealRentItem["lastRegisterTime"] = data["lastRegisterTime"]
        house730DealRentItem["lastBuildingAvgPrice"] = data["lastBuildingAvgPrice"]
        house730DealRentItem["lastHoldDays"] = data["lastHoldDays"]
        house730DealRentItem["profit"] = data["profit"]
        house730DealRentItem["profitPercent"] = data["profitPercent"]
        house730DealRentItem["profitPercentYear"] = data["profitPercentYear"]
        house730DealRentItem["dealType"] = data["dealType"]
        house730DealRentItem["historyDeal"] = data["historyDeal"]
        house730DealRentItem["dealSource"] = data["dealSource"]
        yield house730DealRentItem

import json
import math
from datetime import datetime
import scrapy
from RealEstate.items import House730RentItem
from RealEstate.spiders.House730GeneralSpider import House730GeneralSpider
from RealEstate.items import House730TableauItem


class House730SaleSpider(House730GeneralSpider):
    name = "house730tableausalespider"

    def __init__(self):
        super().__init__(
            start_url="https://api.house730.com/Property/SearchProperty?language=zh-hk&cityen=hk&platform=wap"
            , page_count=100)

    def send_requests(self, page, callback):
        body = {"pageCount": self.page_count, "pageIndex": page, "rentalType": "sale", "regionCon": [], "searchCon": []}

        headers = {"Accept": "application/json, text/plain, */*",
                   "Accept-Language": "zh-TW,zh;q=0.9,en-US;q=0.8,en;q=0.7", "Connection": "keep-alive",
                   "Content-Type": "application/json;charset=UTF-8", "Origin": "https://m.house730.com",
                   "Referer": "https://m.house730.com/", "Sec-Fetch-Dest": "empty", "Sec-Fetch-Mode": "cors",
                   "Sec-Fetch-Site": "same-site",
                   "User-Agent": "Mozilla/5.0 (Linux; Android 6.0; Nexus 5 Build/MRA58N) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/102.0.0.0 Mobile Safari/537.36",
                   "sec-ch-ua": '" Not A;Brand";v="99", "Chromium";v="102", "Google Chrome";v="102"', }
        yield scrapy.Request(method="POST", url=self.start_url, headers=headers, body=json.dumps(body),
                             callback=callback)

    def page_item(self, data):
        house730rentitem = House730TableauItem()
        house730rentitem["propertyID"] = data["propertyID"]
        house730rentitem["regionCode"] = data["regionCode"]
        house730rentitem["regionName"] = data["regionName"]
        house730rentitem["regionNameWithCulture"] = data["regionNameWithCulture"]
        house730rentitem["zoneCode"] = data["zoneCode"]
        house730rentitem["zoneName"] = data["zoneName"]
        house730rentitem["zoneNameEN"] = data["zoneNameEN"]
        house730rentitem["gscopeCode"] = data["gscopeCode"]
        house730rentitem["gscopeName"] = data["gscopeName"]
        house730rentitem["gscopeNameEN"] = data["gscopeNameEN"]
        house730rentitem["estateID"] = data["estateID"]
        house730rentitem["parentEstateID"] = data["parentEstateID"]
        house730rentitem["buildingID"] = data["buildingID"]
        house730rentitem["unitID"] = data["unitID"]
        house730rentitem["estateName"] = data["estateName"]
        house730rentitem["estateNameZH"] = data["estateNameZH"]
        house730rentitem["estateNameEN"] = data["estateNameEN"]
        house730rentitem["estateNameWithCulture"] = data["estateNameWithCulture"]
        house730rentitem["phaseWithCulture"] = data["phaseWithCulture"]
        house730rentitem["phase"] = data["phase"]
        house730rentitem["phaseEn"] = data["phaseEn"]
        house730rentitem["estateAddressWithCulture"] = data["estateAddressWithCulture"]
        house730rentitem["buildingName"] = data["buildingName"]
        house730rentitem["buildingAge"] = data["buildingAge"]
        house730rentitem["propertySource"] = data["propertySource"]
        house730rentitem["propertySourceWithCulture"] = data["propertySourceWithCulture"]
        house730rentitem["rentalType"] = data["rentalType"]
        house730rentitem["rentalTypeWithCulture"] = data["rentalTypeWithCulture"]
        house730rentitem["isLinkParking"] = data["isLinkParking"]
        house730rentitem["buildingArea"] = data["buildingArea"]
        house730rentitem["saleableArea"] = data["saleableArea"]
        house730rentitem["isVerifyArea"] = data["isVerifyArea"]
        house730rentitem["declarIsNeeded"] = data["declarIsNeeded"]
        house730rentitem["propertyCategory"] = data["propertyCategory"]
        house730rentitem["propertyCategoryWithCulture"] = data["propertyCategoryWithCulture"]
        house730rentitem["salePrice"] = data["salePrice"]
        house730rentitem["rentPrice"] = data["rentPrice"]
        house730rentitem["buildingAvgPrice"] = data["buildingAvgPrice"]
        house730rentitem["saleableAvgPrice"] = data["saleableAvgPrice"]
        house730rentitem["dealAvgDate"] = data["dealAvgDate"]
        house730rentitem["dealAvgDateMonth"] = data["dealAvgDateMonth"]
        house730rentitem["dealAvgPrice"] = data["dealAvgPrice"]
        house730rentitem["propertyNo"] = data["propertyNo"]
        house730rentitem["titleWithCulture"] = data["titleWithCulture"]
        house730rentitem["isTitleCurrentCulture"] = data["isTitleCurrentCulture"]
        house730rentitem["isJoinAgentIntroduce"] = data["isJoinAgentIntroduce"]
        house730rentitem["unitFloor"] = data["unitFloor"]
        house730rentitem["unitFloorWithCulture"] = data["unitFloorWithCulture"]
        house730rentitem["roomNumber"] = data["roomNumber"]
        house730rentitem["toiletNumber"] = data["toiletNumber"]
        house730rentitem["toiletNumberWithCulture"] = data["toiletNumberWithCulture"]
        house730rentitem["roomNumberWithCulture"] = data["roomNumberWithCulture"]
        house730rentitem["propertyManagementFee"] = data["propertyManagementFee"]
        house730rentitem["imagePath"] = data["imagePath"]
        house730rentitem["topType"] = data["topType"]
        house730rentitem["topTypeWithCulture"] = data["topTypeWithCulture"]
        house730rentitem["approvalStatus"] = data["approvalStatus"]
        house730rentitem["approvalStatusWithCulture"] = data["approvalStatusWithCulture"]
        house730rentitem["approvalTime"] = self.timestamp_to_date(data["approvalTime"])
        house730rentitem["propertyStatus"] = data["propertyStatus"]
        house730rentitem["propertyStatusWithCulture"] = data["propertyStatusWithCulture"]
        house730rentitem["paymentStatus"] = data["paymentStatus"]
        house730rentitem["paymentStatusWithCulture"] = data["paymentStatusWithCulture"]
        house730rentitem["publicTime"] = self.timestamp_to_date(data["publicTime"])
        house730rentitem["expireTime"] = self.timestamp_to_date(data["expireTime"])
        house730rentitem["browseNumber"] = data["browseNumber"]
        house730rentitem["imageNumber"] = data["imageNumber"]
        house730rentitem["collectionNumber"] = data["collectionNumber"]
        house730rentitem["leaveMessageNumber"] = data["leaveMessageNumber"]
        house730rentitem["isNamely"] = data["isNamely"]
        house730rentitem["isVerify"] = data["isVerify"]
        house730rentitem["isVerifyImage"] = data["isVerifyImage"]
        house730rentitem["isVerifyLabel"] = data["isVerifyLabel"]
        house730rentitem["refreshTime"] = self.timestamp_to_date(data["refreshTime"])
        house730rentitem["recommendNumber"] = data["recommendNumber"]
        house730rentitem["saleForm"] = data["saleForm"]
        house730rentitem["saleFormWithCulture"] = data["saleFormWithCulture"]
        house730rentitem["userID"] = data["userID"]
        house730rentitem["accountID"] = data["accountID"]
        house730rentitem["updateTime"] = self.timestamp_to_date(data["updateTime"])
        house730rentitem["isAdminOffLine"] = data["isAdminOffLine"]
        house730rentitem["introduceWithCulture"] = data["introduceWithCulture"]
        house730rentitem["isIntroduceCurrentCulture"] = data["isIntroduceCurrentCulture"]
        house730rentitem["longitudes"] = data["longitudes"]
        house730rentitem["latitudes"] = data["latitudes"]
        house730rentitem["subCategory"] = data["subCategory"]
        house730rentitem["subCategoryInfos"] = data["subCategoryInfos"]
        house730rentitem["similar"] = data["similar"]
        house730rentitem["images"] = data["images"]
        house730rentitem["planImages"] = data["planImages"]
        house730rentitem["rentLabel"] = data["rentLabel"]
        house730rentitem["rentLabelInfos"] = data["rentLabelInfos"]
        house730rentitem["propertyLabel"] = data["propertyLabel"]
        house730rentitem["propertyLabelInfos"] = data["propertyLabelInfos"]
        house730rentitem["departmentID"] = data["departmentID"]
        house730rentitem["companyID"] = data["companyID"]
        house730rentitem["companyNameWithCulture"] = data["companyNameWithCulture"]
        house730rentitem["vr"] = data["vr"]
        house730rentitem["vrs"] = data["vrs"]
        house730rentitem["videos"] = data["videos"]
        house730rentitem["isHideAgent"] = data["isHideAgent"]
        house730rentitem["isHide"] = data["isHide"]
        house730rentitem["isDelete"] = data["isDelete"]
        house730rentitem["companySource"] = data["companySource"]
        house730rentitem["hideType"] = data["hideType"]
        property_list = self.parse_property_tags(data["propertyTag"])
        house730rentitem["_24HourAccess"] = "24小時出入" in property_list
        house730rentitem["_24HourCCTV"] = "24小時閉路電視" in property_list
        house730rentitem["residentialParkingSpace"] = "住宅車位" in property_list
        house730rentitem["gardenView"] = "內園景" in property_list
        house730rentitem["wholeFloor"] = "全層" in property_list
        house730rentitem["chargingPossible"] = "可供充電" in property_list
        house730rentitem["canInstallCharging"] = "可安裝充電" in property_list
        house730rentitem["petFriendly"] = "可養寵物" in property_list
        house730rentitem["unitWithOneSideFacingOutside"] = "單邊位" in property_list
        house730rentitem["basicDecoration"] = "基本裝修" in property_list
        house730rentitem["indoors"] = "室內" in property_list
        house730rentitem["outdoors"] = "室外" in property_list
        house730rentitem["estateShuttleBus"] = "屋苑專車" in property_list
        house730rentitem["mountainView"] = "山景" in property_list
        house730rentitem["commercialParkingSpace"] = "工商車位" in property_list
        house730rentitem["cityView"] = "市景" in property_list
        house730rentitem["clubhouseFacilities"] = "會所設施" in property_list
        house730rentitem["floorLevelView"] = "樓景" in property_list
        house730rentitem["riverView"] = "河景" in property_list
        house730rentitem["seaView"] = "河景" in property_list
        house730rentitem["independentAirConditioning"] = "獨立冷氣機" in property_list
        house730rentitem["independentWashroom"] = "獨立洗手間" in property_list
        house730rentitem["independentPantry"] = "獨立茶水間" in property_list
        house730rentitem["linked"] = "相連" in property_list
        house730rentitem["duplexApartment"] = "複式" in property_list
        house730rentitem["luxuriousInteriorDecoration"] = "豪華裝修" in property_list
        house730rentitem["nearParkingEntrance"] = "近停車場入口" in property_list
        house730rentitem["nearShoppingMall"] = "近大型商場" in property_list
        house730rentitem["nearMainLobbyElevator"] = "近大堂電梯" in property_list
        house730rentitem["nearMTR"] = "近港鐵" in property_list
        house730rentitem["equippedWithAppliances"] = "連傢電" in property_list
        house730rentitem["withStorageRoom"] = "連儲物室" in property_list
        house730rentitem["withRooftopAccess"] = "連天台" in property_list
        house730rentitem["withSuite"] = "連套房" in property_list
        house730rentitem["withWorkerQuarters"] = "連工人房" in property_list
        house730rentitem["withPlatform"] = "連平台" in property_list
        yield house730rentitem

    def timestamp_to_date(self, timestamp):
        try:
            return datetime.fromtimestamp(timestamp).strftime('%m/%d/%Y')
        except:
            return None

    def parse_property_tags(self, property_tag):
        try:
            return [i["propertyTagName"] for i in property_tag]
        except:
            return []

import json
import math
from datetime import datetime
import scrapy


class House730GeneralSpider(scrapy.Spider):

    def __init__(self, start_url, page_count):
        super().__init__()
        self.start_url = start_url
        self.page_count = page_count

    def send_requests(self, page, callback):
        pass

    def start_requests(self):
        yield from self.send_requests(page=1, callback=self.parse_first_page)

    def parse_first_page(self, response):
        if response.status == 200:

            response_result = response.json()["result"]

            total_items = response_result["count"]
            data_list = response_result["data"]

            for data in data_list:
                yield from self.page_item(data)

            total_page = math.ceil(total_items / self.page_count)
            for page in range(2, total_page):
                yield from self.send_requests(page=page, callback=self.parse_page)

    def parse_page(self, response):
        if response.status == 200:
            response_result = response.json()["result"]
            data_list = response_result["data"]
            for data in data_list:
                yield from self.page_item(data)

    def page_item(self, data):
        pass



